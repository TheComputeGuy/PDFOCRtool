# PDF OCR Tool

PDF OCR Tool is a Python-based tool for adding OCR to PDFs.

## Installation

The downloaded ZIP file consists of two batch scripts
1. setup.bat
2. install-lib.bat

Run both the scripts in the same order **with administrative privileges**. This installs the prerequisites required.

## Usage

The **PDF OCR Tool.exe** runs the application. It consists of two options - the input PDF file and the folder where the output PDF should be saved. The output file will have the name paper.pdf

Conversion takes time and the progress is shown in the console that opens alongside. Once the conversion is complete, the UI shows a message in green saying "File converted and saved successfully!"

In case of errors, the message is printed in the UI with a red background. Contact the maintainers with the error message for resolution.
